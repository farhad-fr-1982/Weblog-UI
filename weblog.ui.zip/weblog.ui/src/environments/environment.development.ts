export const environment = {
    apiBaseUrl: 'https://localhost:7197'
  };
