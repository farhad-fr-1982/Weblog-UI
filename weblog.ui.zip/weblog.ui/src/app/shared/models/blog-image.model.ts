export interface BlogImage {
    id: string;
    fileName: string;
    title: string;
    fileExtenstion: string;
    url: string;
  }