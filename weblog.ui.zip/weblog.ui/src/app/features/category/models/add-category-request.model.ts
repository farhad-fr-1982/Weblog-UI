export interface AddCategoryRerquest{
    name:string;
    urlHandle:string;
}